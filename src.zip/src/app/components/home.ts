import { Component ,OnInit} from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { ActivatedRoute } from '@angular/router';
import {AppServices} from './../app.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.html'
})
export class HomeComponent implements OnInit{
  
  constructor(private http: Http,private route:ActivatedRoute,private appService:AppServices) {}
  
  username:String;
  password:String;
  title = 'app';
  serviceData:any=[];
  matchedFlag:boolean=false;

  ngOnInit(){
    this.route.params.subscribe(params => {
      this.username = params['username']; 
      this.password = params['password']; 
      this.getData();
   });
  }

  getData(){
  this.appService.getJSON().subscribe(result=>{
   console.log(result);
   this.serviceData= result;
   if(this.serviceData[0].username == this.username && this.serviceData[0].password == this.password){
     this.matchedFlag=true;
   }
   else{
     this.matchedFlag= false;
   }
  })
  }
  
 
}

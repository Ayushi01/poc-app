import { Component ,OnInit} from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';


@Component({
  selector: 'app-login',
  templateUrl: './login.html'
})
export class LoginComponent implements OnInit{
  
  constructor(private http: Http) {}

  ngOnInit(){
    
  }
  username:String;
  password:String;
  flag:Boolean=true;
  title = 'app';
}

import { Component ,OnInit} from '@angular/core';
import {AppServices} from './app.service';
import { Http, Response, Headers, RequestOptions } from '@angular/http';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  
  constructor(private http: Http,private appservice : AppServices) {}

  ngOnInit(){
    // this.appservice.getJSON().subscribe(
    //   data => {
    //    console.log(data);
    //   }
    // ,
    //    error => console.log(error));
  }
  title = 'app';
}
